package mino;

import java.awt.*;

public class Block extends Rectangle {
    
    public int x, y;
    public static final int SIZE = 30;  // 30x30 block
    public Color c;

    public Block(Color c) {
        this.c = c;
    }
    
    public void draw(Graphics2D g2){
        int margin = 2;
        int size = SIZE - margin * 2;

        // Ombra leggera sotto il blocco (offset + trasparente nero)
        g2.setColor(new Color(0, 0, 0, 60));
        g2.fillRoundRect(x + margin + 2, y + margin + 2, size, size, 8, 8);

        // Sfumatura verticale dal colore più chiaro a più scuro
        GradientPaint gradient = new GradientPaint(
            x + margin, y + margin, c.brighter(),
            x + margin, y + margin + size, c.darker()
        );
        g2.setPaint(gradient);
        g2.fillRoundRect(x + margin, y + margin, size, size, 8, 8);

        // Bordo sfumato bianco -> grigio chiaro
        GradientPaint borderGradient = new GradientPaint(
            x + margin, y + margin, Color.WHITE,
            x + margin + size, y + margin + size, new Color(200, 200, 200)
        );
        g2.setPaint(borderGradient);
        g2.setStroke(new BasicStroke(2));
        g2.drawRoundRect(x + margin, y + margin, size, size, 8, 8);

        // Lucentezza morbida (cerchio sfumato bianco semi trasparente)
        RadialGradientPaint shine = new RadialGradientPaint(
            new Point(x + margin + size/4, y + margin + size/4),
            size/3,
            new float[]{0f, 1f},
            new Color[]{new Color(255, 255, 255, 150), new Color(255, 255, 255, 0)}
        );
        g2.setPaint(shine);
        g2.fillOval(x + margin, y + margin, size, size);
    }
    
}

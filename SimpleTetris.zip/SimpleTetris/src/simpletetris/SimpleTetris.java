package simpletetris;

import javax.swing.JFrame;

public class SimpleTetris {

    public static JFrame window;
    public static GamePanel gamePanel;
    public static MainMenu mainMenu;

    public static void main(String[] args) {
        window = new JFrame("Simple Tetris");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setResizable(false);
        mainMenu = new MainMenu(window);
        window.setContentPane(mainMenu);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }

    public static void startGame() {
        mainMenu.setVisible(false);

        gamePanel = new GamePanel(window); // ← sempre nuovo pannello
        window.setContentPane(gamePanel);
        gamePanel.requestFocusInWindow();
        gamePanel.launchGame();
    }


    public static void showMainMenu() {
        if (gamePanel != null) {
            gamePanel = null;
        }
        mainMenu.setVisible(true);
        window.setContentPane(mainMenu);
        mainMenu.requestFocusInWindow();
    }
}

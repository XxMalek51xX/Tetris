package simpletetris;

import java.awt.event.*;

public class KeyHandler implements KeyListener {
    
    public static boolean upPressed, downPressed, leftPressed, rightPressed, spacePressed,cPressed, Zbutton, Xbutton;
    public static boolean enterPressed = false;
    public static boolean pausePressed = false;
    public static boolean escPressed = false;

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
        int code = e.getKeyCode();

        if(code == KeyEvent.VK_DOWN){
            downPressed = true;
        }
        if(code == KeyEvent.VK_LEFT){
            leftPressed = true;
        }
        if(code == KeyEvent.VK_RIGHT){
            rightPressed = true;
        }
        if (code == KeyEvent.VK_ENTER) {
            pausePressed = !pausePressed;
        }

        if (code == KeyEvent.VK_ESCAPE) {
            escPressed = true;
        }
        if(code == KeyEvent.VK_C){
            cPressed = true;
        }
        if(code == KeyEvent.VK_SPACE){
            spacePressed = true;
        }

        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();

        if(code == KeyEvent.VK_Z){
            Zbutton = true;
        }
        if(code == KeyEvent.VK_X){
            Xbutton = true;
        }
        if(code == KeyEvent.VK_C){
            cPressed = false;
        }
        if(code == KeyEvent.VK_SPACE){
            spacePressed = false;
        }
        if (code == KeyEvent.VK_ESCAPE) {
            escPressed = false;
        }
    }
    
}

package simpletetris;
 
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import mino.Block;
import mino.Mino;
import mino.Mino_Bar;
import mino.Mino_L1;
import mino.Mino_L2;
import mino.Mino_Square;
import mino.Mino_T;
import mino.Mino_Z1;
import mino.Mino_Z2;

public class PlayManager {
    
    // Main Play Area
    
    final int WIDTH = 360;
    final int HEIGHT = 600;
    public static int left_x;
    public static int right_x;
    public static int top_y;
    public static int bottom_y;
    
    //Mino
    Mino currentMino;
    final int MINO_START_Y;
    final int MINO_START_X;
    Mino nextMino;
    final int NEXTMINO_X;
    final int NEXTMINO_Y;
    Mino holdMino = null;   // il mino in hold, inizialmente nullo
    boolean holdUsed = false; // per evitare hold multipli consecutivi senza piazzare
    final int HOLD_X;  // da inizializzare nel costruttore
    final int HOLD_Y;
    public static ArrayList<Block> staticBlocks = new ArrayList<>();
    
    private ArrayList<Mino> minoBag = new ArrayList<>();
    //Others 
    public static int dropInterval = 60; //The mino drops 60 frames
    public boolean gameOver = false;

    
    // Effects
    boolean effectCounterOn;
    int effectCounter;
    ArrayList<Integer> effectY = new ArrayList<>();
    
    //Score
    int level = 1;
    int lines;
    int score;

    public PlayManager() {
        
        left_x = (GamePanel.WIDTH/2) - (WIDTH/2); // 1280/2 - 360/2 = 460
        right_x = left_x + WIDTH;
        top_y = 50;
        bottom_y = top_y + HEIGHT;
        
        MINO_START_X = left_x + (WIDTH/2) -Block.SIZE;
        MINO_START_Y = top_y + Block.SIZE;
        
        NEXTMINO_X = right_x + 170;
        NEXTMINO_Y = top_y + 500;
        
        HOLD_X = left_x - 220;
        HOLD_Y = top_y + 20;
        // Set the starting Mino
        currentMino = pickMino();
        currentMino.setXY(MINO_START_X, MINO_START_Y);
        nextMino = pickMino();
        nextMino.setXY(NEXTMINO_X, NEXTMINO_Y);
        
    }
    private Mino pickMino() {
        if (minoBag.isEmpty()) {
            refillMinoBag();
        }
        return minoBag.remove(0);
    }

    public void resetGame() {
        staticBlocks.clear();
        dropInterval = 60;
        gameOver = false;
        effectCounterOn = false;
        effectCounter = 0;
        effectY.clear();

        level = 1;
        lines = 0;
        score = 0;
        minoBag.clear();

        holdMino = null;
        holdUsed = false;

        currentMino = pickMino();
        currentMino.setXY(MINO_START_X, MINO_START_Y);
        nextMino = pickMino();
        nextMino.setXY(NEXTMINO_X, NEXTMINO_Y);
    }

    
    private void refillMinoBag() {
        ArrayList<Mino> allTypes = new ArrayList<>();
        allTypes.add(new Mino_L1());
        allTypes.add(new Mino_L2());
        allTypes.add(new Mino_Square());
        allTypes.add(new Mino_Bar());
        allTypes.add(new Mino_T());
        allTypes.add(new Mino_Z1());
        allTypes.add(new Mino_Z2());

        // Mischia l'elenco
        Random rand = new Random();
        while (!allTypes.isEmpty()) {
            int index = rand.nextInt(allTypes.size());
            minoBag.add(allTypes.remove(index));
        }
    }

    
    public void update(){
        
        if (gameOver) {
            return; // Blocca tutta la logica del gioco se il game over è attivo
        }
        
        if(KeyHandler.cPressed && !holdUsed){
            holdUsed = true;  // blocca finché C non viene rilasciato
            KeyHandler.cPressed = false;

            if(holdMino == null){
                // Primo uso: metto current in hold e prendo next come current
                holdMino = currentMino;
                holdMino.setXY(HOLD_X + 50, HOLD_Y + 80);

                currentMino = nextMino;
                currentMino.setXY(MINO_START_X, MINO_START_Y);
                nextMino = pickMino();
                nextMino.setXY(NEXTMINO_X, NEXTMINO_Y);

            } else {
                // Scambio current e hold
                Mino temp = currentMino;
                currentMino = holdMino;
                currentMino.setXY(MINO_START_X, MINO_START_Y);

                holdMino = temp;
                holdMino.setXY(HOLD_X + 50, HOLD_Y + 80);
            }
        }
        if(KeyHandler.spacePressed){
            boolean canDrop = true;
            while(canDrop){
                // Verifica se può scendere ancora
                for(int i = 0; i < 4; i++){
                    int newY = currentMino.b[i].y + Block.SIZE;

                    // Fuori dal campo?
                    if(newY >= bottom_y){
                        canDrop = false;
                        break;
                    }

                    // Collisione con blocchi statici
                    for(Block b : staticBlocks){
                        if(currentMino.b[i].x == b.x && newY == b.y){
                            canDrop = false;
                            break;
                        }
                    }

                    if(!canDrop) break;
                }

                // Se può scendere, sposta tutti i blocchi in giù
                if(canDrop){
                    for(int i = 0; i < 4; i++){
                        currentMino.b[i].y += Block.SIZE;
                    }
                }
            }

            // Dopo il drop forzato, consideralo come "piazzato"
            currentMino.active = false;
            KeyHandler.spacePressed = false;
        }


        // Resetta holdUsed anche quando il pezzo viene piazzato, così puoi fare hold dopo il piazzamento
        if(currentMino.active == false){
            holdUsed = false;

            staticBlocks.add(currentMino.b[0]);
            staticBlocks.add(currentMino.b[1]);
            staticBlocks.add(currentMino.b[2]);
            staticBlocks.add(currentMino.b[3]);

            if(currentMino.b[0].x == MINO_START_X && currentMino.b[0].y == MINO_START_Y){
                gameOver = true;
            }

            currentMino.deactivating = false;

            currentMino = nextMino;
            currentMino.setXY(MINO_START_X, MINO_START_Y);
            nextMino = pickMino();
            nextMino.setXY(NEXTMINO_X, NEXTMINO_Y);

            checkDelete();
        } else {
            currentMino.update();
        }
    }
    private void checkDelete(){
        
        int x = left_x;
        int y = top_y;
        int blockCount = 0;
        int lineCount = 0;
        
        while(x < right_x && y < bottom_y){
            
            for(int i = 0;i < staticBlocks.size(); i++){
                if(staticBlocks.get(i).x == x && staticBlocks.get(i).y == y){
                    blockCount++;
                }
            }
            
            x += Block.SIZE;
            
            if(x == right_x){
                
                if(blockCount == 12){
                    
                   effectCounterOn = true;
                   effectY.add(y);
                    
                    for(int i = staticBlocks.size()-1; i > -1; i--){
                        if(staticBlocks.get(i).y == y){
                            staticBlocks.remove(i);
                        }
                    }
                    
                    lineCount++;
                    lines++;
                    // Drop Speed
                    
                    if(lines % 10 == 0 && dropInterval > 1){
                        
                        level++;
                        if(dropInterval > 10){
                            dropInterval -= 10;
                        }else{
                            dropInterval -= 1;
                        }
                        
                    }
                    
                    
                    for(int i = 0;i <staticBlocks.size(); i++){
                        if ( staticBlocks.get(i).y < y){
                            staticBlocks.get(i).y += Block.SIZE;
                        }
                    }
                    
                }
                
                blockCount = 0;
                x = left_x;
                y += Block.SIZE;
            }
        }
        
        if(lineCount>0){
            int singleLineScore = 10 * level;
            score += singleLineScore * lineCount;
        }
        
    }
    
    
        public void draw(Graphics2D g2) {
        // Imposta il rendering per qualità migliore
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Draw Play Area Frame
        g2.setColor(Color.white);
        g2.setStroke(new BasicStroke(4f));
        g2.drawRect(left_x - 4, top_y - 4, WIDTH + 8, HEIGHT + 8);

        // ---------- NEXT MINO FRAME ----------
        int nextX = right_x + 100;
        int nextY = bottom_y - 200;
        g2.setColor(new Color(30, 30, 30)); // sfondo scuro
        g2.fillRoundRect(nextX, nextY, 200, 200, 20, 20);
        g2.setColor(Color.white);
        g2.setStroke(new BasicStroke(3f));
        g2.drawRoundRect(nextX, nextY, 200, 200, 20, 20);

        g2.setFont(new Font("Arial", Font.BOLD, 28));
        g2.drawString("NEXT", nextX + 60, nextY + 50);

        // ---------- SCORE FRAME ----------
        int scoreX = right_x + 100;
        int scoreY = top_y;
        g2.setColor(new Color(30, 30, 30));
        g2.fillRoundRect(scoreX, scoreY, 250, 300, 20, 20);
        g2.setColor(Color.white);
        g2.drawRoundRect(scoreX, scoreY, 250, 300, 20, 20);

        g2.setFont(new Font("Arial", Font.BOLD, 26));
        int textX = scoreX + 30;
        int lineY = scoreY + 80;
        g2.drawString("LEVEL: " + level, textX, lineY); lineY += 70;
        g2.drawString("LINES: " + lines, textX, lineY); lineY += 70;
        g2.drawString("SCORE: " + score, textX, lineY);

        // ---------- HOLD FRAME ----------
        int holdX = left_x - 220;
        int holdY = top_y + 20;
        g2.setColor(new Color(30, 30, 30));
        g2.fillRoundRect(holdX, holdY, 200, 200, 20, 20);
        g2.setColor(Color.white);
        g2.drawRoundRect(holdX, holdY, 200, 200, 20, 20);

        g2.setFont(new Font("Arial", Font.BOLD, 28));
        g2.drawString("HOLD", holdX + 60, holdY + 50);
        
        // Disegna il mino in hold, se presente
        if(holdMino != null){
            holdMino.draw(g2);
        }
        
        Mino ghostMino = currentMino.getGhostMino();

        // Disegna il ghost con colore trasparente o più chiaro
        float alpha = 0.3f; // trasparenza 30%
        Color ghostColor = new Color(
            ghostMino.b[0].c.getRed(),
            ghostMino.b[0].c.getGreen(),
            ghostMino.b[0].c.getBlue(),
            (int)(alpha * 255)
        );
        g2.setColor(ghostColor);

        int margin = 2;
        for (int i = 0; i < 4; i++) {
            g2.fillRect(
                ghostMino.b[i].x + margin,
                ghostMino.b[i].y + margin,
                Block.SIZE - (margin * 2),
                Block.SIZE - (margin * 2)
            );
        }

        //Draw the currentMino
        if(currentMino != null){
            currentMino.draw(g2);
        }
        
        //Draw NextMino
        nextMino.draw(g2);
        
        for(int i=0;i<staticBlocks.size();i++){
            staticBlocks.get(i).draw(g2);
        }
        
        // Draw Effect
        if (effectCounterOn) {

            effectCounter++;

            float beta = 1.0f - (effectCounter / 30.0f); // da 1 a 0
            beta = Math.max(0, beta); // evita valori negativi
            int teta = (int)(beta * 255);

            g2.setColor(new Color(255, 100, 100, teta));
            for (int i = 0; i < effectY.size(); i++) {
                int z = effectY.get(i);
                g2.fillRect(left_x, z, WIDTH, Block.SIZE);
            }

            if(effectCounter >= 30){
                effectCounterOn = false;
                effectCounter = 0;
                effectY.clear();
            }
        }

        
        // Draw Pause
        g2.setColor(Color.yellow);
        g2.setFont(g2.getFont().deriveFont(50f));
        // --- MESSAGGIO GAME OVER ---
        if (gameOver) {
        String message = "GAME OVER";
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 60f));

        FontMetrics fm = g2.getFontMetrics();
        int textWidth = fm.stringWidth(message);
        int gameOverX = left_x + (WIDTH - textWidth) / 2;
        int gameOverY = top_y + HEIGHT / 2;

        // Ombra
        g2.setColor(Color.BLACK);
        g2.drawString(message, gameOverX + 4, gameOverY + 4);

        // Testo principale
        g2.setColor(Color.RED);
        g2.drawString(message, gameOverX, gameOverY);
    }


        // --- TITOLO ---
        int titleX = 50;
        int titleY = top_y + 450;

        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Times New Roman", Font.ITALIC, 60));
        g2.drawString("Simple Tetris", titleX, titleY);

    }
    
}

package simpletetris;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainMenu extends JPanel {

    private JFrame parentFrame;
    private JButton playButton;
    private JButton exitButton;

    public MainMenu(JFrame frame) {
        this.parentFrame = frame;
        setPreferredSize(new Dimension(GamePanel.WIDTH, GamePanel.HEIGHT));
        setLayout(new GridBagLayout());

        setBackground(Color.BLACK);

        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Simple Tetris") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setFont(getFont());
                g2.setColor(new Color(0, 0, 0, 150)); // shadow
                g2.drawString(getText(), 2, getHeight() - 10);
                g2.setColor(getForeground());
                g2.drawString(getText(), 0, getHeight() - 12);
                g2.dispose();
            }
        };
        title.setFont(new Font("Segoe UI Black", Font.BOLD, 64));
        title.setForeground(Color.WHITE);
        title.setPreferredSize(new Dimension(600, 80));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 50, 0));

        // Pulsante Gioca
        playButton = createMenuButton("> Gioca");
        playButton.addActionListener(e -> {
            GamePanel gamePanel = new GamePanel(parentFrame);
            parentFrame.setContentPane(gamePanel);
            parentFrame.revalidate();
            gamePanel.launchGame();
            gamePanel.requestFocusInWindow();
        });

        // Pulsante Tasti
        JButton keysButton = createMenuButton("Controlli ");
        keysButton.addActionListener(e -> showControlsDialog());

        // Pulsante Esci
        exitButton = createMenuButton("X Esci");
        exitButton.addActionListener(e -> System.exit(0));

        // Aggiunta al pannello
        panel.add(title);
        panel.add(playButton);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(keysButton);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(exitButton);


        add(panel);
    }

    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 26));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(40, 40, 40));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(240, 60));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setOpaque(true);

        // Effetto hover
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(90, 90, 90));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(40, 40, 40));
            }
        });

        return button;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        Color startColor = new Color(20, 20, 20);
        Color endColor = new Color(70, 70, 70);

        GradientPaint gp = new GradientPaint(0, 0, startColor, 0, getHeight(), endColor);
        g2.setPaint(gp);
        g2.fillRect(0, 0, getWidth(), getHeight());
    }
    private void showControlsDialog() {
       String message =
    "🎮 COMANDI DI GIOCO:\n\n" +
    "Freccia Sinistra - Muovi a sinistra\n" +
    "Freccia Destra   - Muovi a destra\n" +
    "Z                - Ruota il pezzo a sinistra\n" +
    "X                - Ruota il pezzo a destra\n" + 
    "C                - Tieni il pezzo\n" +
    "Freccia Giù      - Accelera discesa\n" +
    "Spazio           - Drop istantaneo\n" +
    "Esc              - Esci\n" +
    "Invio            - Pausa"; 
        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 16));
        textArea.setBackground(new Color(30, 30, 30));
        textArea.setForeground(Color.WHITE);

        JOptionPane.showMessageDialog(this, textArea, "Tasti di Gioco", JOptionPane.INFORMATION_MESSAGE);
    }

}

package simpletetris;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GamePanel extends JPanel implements Runnable {
    
    public static final int WIDTH = 1280;
    public static final int HEIGHT = 720;
    final int FPS = 60;
    Thread gameThread;
    PlayManager pm;
    private JFrame parentFrame;
    
    boolean paused = false;

    public GamePanel(JFrame frame) {
        this.parentFrame = frame;

        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setBackground(Color.black);
        this.setLayout(null);
        this.addKeyListener(new KeyHandler());
        this.setFocusable(true);

        pm = new PlayManager();
    }
    
    public void launchGame(){
        pm.resetGame(); // Resetta il gioco ogni volta che viene lanciato

        if (gameThread == null || !gameThread.isAlive()) {
            gameThread = new Thread(this);
            gameThread.start();
        }
    }

    @Override
    public void run() {
        
        double drawInterval = 1000000000 / FPS;
        double delta = 0;
        long lastTime = System.nanoTime();
        long currentTime;
        
        while(gameThread != null){
         
            currentTime = System.nanoTime();
            delta += (currentTime - lastTime) / drawInterval;
            lastTime = currentTime;
            
            if(delta >= 1){
                update();
                repaint();
                delta--;
            }
        }
    }
    
    private void update() {
        if (KeyHandler.pausePressed) {
            paused = !paused;
            KeyHandler.pausePressed = false;
        }

        // ESC -> chiudi il gioco e torna al menu
        if (KeyHandler.escPressed) {
            gameThread = null; // ferma il loop
            KeyHandler.escPressed = false;

            parentFrame.dispose(); // chiudi finestra gioco

            // crea nuova finestra menu principale
            JFrame newWindow = new JFrame("Simple Tetris");
            newWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            newWindow.setResizable(false);
            MainMenu menu = new MainMenu(newWindow);
            newWindow.setContentPane(menu);
            newWindow.pack();
            newWindow.setLocationRelativeTo(null);
            newWindow.setVisible(true);
            return;
        }

        // ⚠️ CONTROLLA GAME OVER
        if (pm.gameOver) {
        gameThread = null; // ferma il loop

        String message = "<html><div style='text-align: center;'>"
            + "<h2 style='color: red;'>GAME OVER</h2>"
            + "<p style='font-size:16px;'>Punteggio: <b>" + pm.score + "</b></p>"
            + "</div></html>";

        JOptionPane.showMessageDialog(this, message, "Game Over", JOptionPane.INFORMATION_MESSAGE);

        returnToMainMenu();
        return;
    }


        if (!paused) {
            pm.update();
        }
    }

    
    @Override

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;
        pm.draw(g2);

        if (paused) {
            // Sfondo semitrasparente al centro
            int boxWidth = 400;
            int boxHeight = 150;
            int boxX = (WIDTH - boxWidth) / 2;
            int boxY = (HEIGHT - boxHeight) / 2;

            // Sfondo arrotondato semi-trasparente
            g2.setColor(new Color(0, 0, 0, 180));
            g2.fillRoundRect(boxX, boxY, boxWidth, boxHeight, 30, 30);

            // Ombra del testo
            g2.setFont(new Font("Segoe UI", Font.BOLD, 56));
            String text = "PAUSA";
            FontMetrics fm = g2.getFontMetrics();
            int textWidth = fm.stringWidth(text);
            int textX = (WIDTH - textWidth) / 2;
            int textY = boxY + boxHeight / 2 + fm.getAscent() / 2 - 10;

            g2.setColor(Color.DARK_GRAY);
            g2.drawString(text, textX + 3, textY + 3); // Ombra

            // Testo principale
            g2.setColor(Color.WHITE);
            g2.drawString(text, textX, textY);
        }
    }


    private void returnToMainMenu() {
        this.setVisible(false); // Nascondi il pannello di gioco
        pm.resetGame(); // Riavvia la partita
        SimpleTetris.showMainMenu(); // Metodo statico per tornare al menu principale
    }
}

